package com.biwash.inventory_mgt;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;

@RequiresApi(api = Build.VERSION_CODES.M)
public class Dashboard extends AppCompatActivity  {

    private CardView D1,D2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        D1 = (CardView) findViewById(R.id.D1);
        D2 = (CardView) findViewById(R.id.D2);

//        D1.setOnContextClickListener(this);
//        D2.setOnContextClickListener(this);

        D1.setOnClickListener(new View.OnClickListener()
        {


            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this,MainActivity.class);
                startActivity(intent);
            }
        });

        D2.setOnClickListener(new View.OnClickListener()
        {


            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this,Notification.class);
                startActivity(intent);
            }
        });

    }


//    @Override
//    public boolean onContextClick(View v) {
//
//        Intent i;
//
//        switch(v.getId())
//        {
//            case R.id.D1: i = new Intent(this, MainActivity.class); startActivity(i); break;
//            case R.id.D2: i = new Intent(this, MainActivity.class); startActivity(i); break;
//            default:break;
//
//        }
//        return false;
//    }
}
